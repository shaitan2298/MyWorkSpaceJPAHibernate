package com.cg.pizza.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.PizzaOrders;

public class OrderDAOImpl implements OrderDAO
{
	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public PizzaOrders save(PizzaOrders order) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(order);
		entityManager.getTransaction().commit();
		entityManager.close();
		return order;
	}

	@Override
	public boolean update(PizzaOrders order) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(order);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

	@Override
	public PizzaOrders findOne(int orderId) {
		return entityManagerFactory.createEntityManager().find(PizzaOrders.class,orderId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PizzaOrders> findAll() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createQuery("from Customer a",Customer.class);
		return query.getResultList();
	}

}
